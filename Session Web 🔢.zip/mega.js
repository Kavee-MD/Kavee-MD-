const mega = require("megajs");

const credentials = {
  email: 'lakamdbot@gmail.com',
  password: 'Mrlakaofcbot',
  userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246"
};

const upload = (fileStream, fileName) => {
  return new Promise((resolve, reject) => {
    try {
      const storage = new mega.Storage(credentials, () => {
        const options = {
          name: fileName,
          allowUploadBuffering: true
        };
        fileStream.pipe(storage.upload(options));
        storage.on("add", file => {
          file.link((error, link) => {
            if (error) {
              throw error;
            }
            storage.close();
            resolve(link);
          });
        });
      });
    } catch (error) {
      reject(error);
    }
  });
};

module.exports = { upload };